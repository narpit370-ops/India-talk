# India Talk Android release project

Package: `com.indiatalk.app`
Founder: Arpit Nayak

## What is included in this upgraded build
- India Talk branded home/chats screen
- Chats, Status, Calls and More navigation
- Local demo conversation and Family Group conversation
- Profile screen
- Settings screen
- Media Sharing screen
- End-to-End Encryption information screen
- Local demo actions for camera, media, audio and poll buttons
- Firebase Messaging service hook retained for later backend integration

## Important
This is a **working local UI/demo build**, not yet a production messaging service. Real authentication, Firestore/database persistence, file storage, voice/video calling, push-token registration and server API wiring still need to be connected before public launch.

## Build
1. Install Android Studio and JDK 17.
2. Open this `android/` directory.
3. Put your real Firebase `google-services.json` in `android/app/` (or temporarily remove the Google Services plugin if you only want a UI-only build).
4. Sync Gradle.
5. Run the app on a physical Android device or emulator.
6. For a shareable test APK use **Build → Generate App Bundles or APKs → Generate APKs**.
7. For Google Play use a signed **Android App Bundle (.aab)** and a production signing key.

## No-payment testing
You can install a debug/test APK directly on Android devices without publishing to Google Play. Google Play public distribution is a separate step and requires Play Console registration.
