# India Talk release rules
# Keep Firebase/Google services metadata.
-keep class com.google.firebase.** { *; }
