package com.indiatalk.app

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val orange = Color.rgb(255, 122, 0)
    private val green = Color.rgb(7, 136, 59)
    private val blue = Color.rgb(23, 79, 138)
    private val dark = Color.rgb(30, 30, 30)
    private val light = Color.rgb(247, 249, 247)
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun showHome() {
        root = baseRoot()
        root.addView(appBar("India Talk", "🇮🇳"))

        val notice = TextView(this).apply {
            text = "Demo mode • Local UI test • Backend/Firebase not connected"
            setTextColor(blue)
            setBackgroundColor(Color.rgb(232, 241, 250))
            setPadding(dp(14), dp(9), dp(14), dp(9))
            textSize = 12f
        }
        root.addView(notice, lp())

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(10), dp(8), dp(10), dp(4)) }
        listOf("All", "Unread", "Groups").forEachIndexed { i, t ->
            val b = Button(this).apply {
                text = t
                textSize = 12f
                isAllCaps = false
                setTextColor(if (i == 0) Color.WHITE else dark)
                setBackgroundColor(if (i == 0) orange else Color.TRANSPARENT)
                setOnClickListener { showHome() }
            }
            tabs.addView(b, LinearLayout.LayoutParams(0, dp(40), 1f))
        }
        root.addView(tabs, lp())

        val chats = listOf(
            Chat("Arpit Nayak", "Hey! How are you?", "9:41 AM", "2"),
            Chat("Family Group", "Mom: Dinner at 7 PM 🍲", "9:30 AM", "5"),
            Chat("Priya Patel", "Photo", "9:18 AM", "1"),
            Chat("Rohit Sharma", "Thanks bhai 👍", "8:45 AM", "2"),
            Chat("Sneha", "Audio", "Yesterday", ""),
            Chat("Office Team", "Vikram: File uploaded", "Yesterday", ""),
            Chat("Mom", "Take care beta ❤️", "Yesterday", "")
        )
        chats.forEach { chat -> root.addView(chatRow(chat), lp()) }

        val spacer = Space(this)
        root.addView(spacer, LinearLayout.LayoutParams(1, 0, 1f))
        root.addView(bottomNav(0), lp())
        setContentView(root)
    }

    private fun showStatus() {
        root = baseRoot()
        root.addView(appBar("Status", ""))
        root.addView(sectionTitle("My Status", "Tap to add status update", "➕"), lp())
        root.addView(label("Recent updates", green, true), lp())
        listOf("Priya Patel" to "2 minutes ago", "Rohit Sharma" to "10 minutes ago", "Sneha" to "30 minutes ago", "Vikram Singh" to "1 hour ago", "Mom" to "2 hours ago").forEach {
            root.addView(statusRow(it.first, it.second), lp())
        }
        root.addView(Space(this), LinearLayout.LayoutParams(1, 0, 1f))
        root.addView(bottomNav(1), lp())
        setContentView(root)
    }

    private fun showCalls() {
        root = baseRoot()
        root.addView(appBar("Calls", "📞"))
        val segmented = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(12), dp(8), dp(12), dp(8)) }
        listOf("All", "Missed").forEachIndexed { i, t ->
            val b = Button(this).apply { text = t; isAllCaps = false; textSize = 12f; setTextColor(if (i == 0) orange else dark) }
            segmented.addView(b, LinearLayout.LayoutParams(0, dp(42), 1f))
        }
        root.addView(segmented, lp())
        listOf("Arpit Nayak" to "Today, 9:30 AM", "Priya Patel" to "Today, 9:15 AM", "Dad" to "Yesterday, 8:45 PM", "Sneha" to "Yesterday, 4:20 PM", "Rohit Sharma" to "22 May, 7:10 PM", "Mom" to "20 May, 10:05 AM").forEach { root.addView(callRow(it.first, it.second), lp()) }
        root.addView(Space(this), LinearLayout.LayoutParams(1, 0, 1f))
        root.addView(bottomNav(2), lp())
        setContentView(root)
    }

    private fun showMore() {
        root = baseRoot()
        root.addView(appBar("More", "⋮"))
        root.addView(profileCard(), lp())
        root.addView(menuRow("👤", "Profile", "View your India Talk profile") { showProfile() }, lp())
        root.addView(menuRow("⚙", "Settings", "Privacy, chats, notifications and data") { showSettings() }, lp())
        root.addView(menuRow("🖼", "Media Sharing", "Gallery, camera, video, documents and more") { showMedia() }, lp())
        root.addView(menuRow("🔐", "End-to-End Encryption", "Learn how your messages are protected") { showEncryption() }, lp())
        root.addView(menuRow("ℹ", "About India Talk", "Secure, simple and made for India") { aboutDialog() }, lp())
        root.addView(Space(this), LinearLayout.LayoutParams(1, 0, 1f))
        root.addView(bottomNav(3), lp())
        setContentView(root)
    }

    private fun showChat(name: String, group: Boolean = false) {
        root = baseRoot()
        val title = if (group) "Family Group" else name
        root.addView(chatBar(title, if (group) "8 members, online" else "online"))
        val scroll = ScrollView(this)
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(12), dp(10), dp(10)) }
        val security = TextView(this).apply {
            text = "🔒 Messages and calls are end-to-end encrypted. No one outside of this chat, not even India Talk, can read or listen to them."
            textSize = 12f; setTextColor(dark); setBackgroundColor(Color.rgb(255, 244, 211)); setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        body.addView(security, lp())
        if (group) {
            addBubble(body, "Mom", "Good morning everyone 🌸", false)
            addBubble(body, "You", "Good morning Mom 😊", true)
            addBubble(body, "Rohit Sharma", "Have a great day all!", false)
            addBubble(body, "Priya Patel", "Wow beautiful! 😍", false)
        } else {
            addBubble(body, "You", "Hi Arpit! 👋", true)
            addBubble(body, name, "Hello! 😊", false)
            addBubble(body, "You", "India Talk looks amazing! 🔥", true)
            addBubble(body, name, "Thanks! 🙏", false)
            addBubble(body, "Voice message", "▶  •••••••••••  0:12", true)
        }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val input = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(6), dp(8), dp(6)) }
        val text = EditText(this).apply { hint = "Type a message"; textSize = 14f; singleLine = true }
        input.addView(text, LinearLayout.LayoutParams(0, dp(52), 1f))
        listOf("📎", "📷", "🎙").forEach { icon ->
            val b = Button(this).apply { this.text = icon; isAllCaps = false; setOnClickListener { Toast.makeText(this@MainActivity, "Demo action", Toast.LENGTH_SHORT).show() } }
            input.addView(b, LinearLayout.LayoutParams(dp(52), dp(52)))
        }
        root.addView(input, lp())
        setContentView(root)
    }

    private fun showProfile() {
        simplePage("Profile") {
            addView(centerAvatar("👨🏻", "Arpit Nayak"))
            addView(label("Hey there! I am using India Talk.", dark, false), lp())
            addView(infoRow("📱", "+91 98765 43210", "Mobile"), lp())
            addView(infoRow("ℹ", "Always believe in yourself 💪", "About"), lp())
            addView(infoRow("🗂", "128", "Media, Links and Docs"), lp())
        }
    }

    private fun showSettings() {
        simplePage("Settings") {
            addView(infoRow("👤", "Arpit Nayak", "Hey there! I am using India Talk."), lp())
            addView(menuRow("👤", "Account", "Privacy, security, change number") {}, lp())
            addView(menuRow("🔒", "Privacy", "Block contacts, disappearing messages") {}, lp())
            addView(menuRow("💬", "Chats", "Theme, wallpapers, chat history") {}, lp())
            addView(menuRow("🔔", "Notifications", "Message, group & call tones") {}, lp())
            addView(menuRow("◔", "Data and Storage Usage", "Network usage, auto-download") {}, lp())
            addView(menuRow("❓", "Help", "Help center, contact us") { aboutDialog() }, lp())
        }
    }

    private fun showMedia() {
        simplePage("Media Sharing") {
            addView(label("Share photos, videos, documents and more", dark, true), lp())
            val grid = GridLayout(this@MainActivity).apply { columnCount = 2; setPadding(dp(8), dp(8), dp(8), dp(8)) }
            listOf("🖼 Gallery", "📷 Camera", "🎥 Video", "📄 Document", "📍 Location", "👤 Contact", "🎵 Audio", "📊 Poll").forEach { item ->
                val b = Button(this@MainActivity).apply { text = item; isAllCaps = false; setOnClickListener { Toast.makeText(this@MainActivity, "$item • Demo", Toast.LENGTH_SHORT).show() } }
                grid.addView(b, GridLayout.LayoutParams().apply { width = 0; height = dp(70); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(dp(4), dp(4), dp(4), dp(4)) })
            }
            addView(grid, lp())
        }
    }

    private fun showEncryption() {
        simplePage("End-to-End Encryption") {
            addView(centerAvatar("🔐", "Your messages and calls are\nend-to-end encrypted"))
            addView(label("No one outside of this chat, not even India Talk, can read or listen to them.", dark, false), lp())
            addView(label("Learn more", green, true), lp())
        }
    }

    private fun simplePage(title: String, content: LinearLayout.() -> Unit) {
        root = baseRoot()
        root.addView(appBar(title, "‹"))
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)) }
        body.content()
        root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Button(this).apply { text = "Back to More"; isAllCaps = false; setOnClickListener { showMore() } }, lp())
        setContentView(root)
    }

    private fun chatRow(c: Chat): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(10), dp(10), dp(10)); setBackgroundColor(Color.WHITE) }
        val avatar = TextView(this).apply { text = if (c.name == "Family Group") "👨‍👩‍👧" else "👤"; textSize = 28f; gravity = Gravity.CENTER }
        row.addView(avatar, LinearLayout.LayoutParams(dp(52), dp(62)))
        val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        mid.addView(label(c.name, dark, true), lp())
        mid.addView(label(c.message, Color.DKGRAY, false), lp())
        row.addView(mid, LinearLayout.LayoutParams(0, -2, 1f))
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT }
        right.addView(label(c.time, green, false), lp())
        if (c.badge.isNotEmpty()) right.addView(badge(c.badge), lp())
        row.addView(right, LinearLayout.LayoutParams(dp(70), -2))
        row.setOnClickListener { if (c.name == "Family Group") showChat(c.name, true) else showChat(c.name) }
        return row
    }

    private fun statusRow(name: String, time: String): View = infoRow("🟢", name, time)
    private fun callRow(name: String, time: String): View = infoRow("📞", name, time)

    private fun infoRow(icon: String, title: String, subtitle: String): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(12), dp(10), dp(12)) }
        row.addView(TextView(this).apply { text = icon; textSize = 24f }, LinearLayout.LayoutParams(dp(50), dp(58)))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(label(title, dark, true), lp())
        col.addView(label(subtitle, Color.DKGRAY, false), lp())
        row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        return row
    }

    private fun sectionTitle(title: String, subtitle: String, icon: String): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(12)) }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(label(title, dark, true), lp())
        col.addView(label(subtitle, Color.DKGRAY, false), lp())
        row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(TextView(this).apply { text = icon; textSize = 26f }, LinearLayout.LayoutParams(dp(50), dp(50)))
        return row
    }

    private fun menuRow(icon: String, title: String, subtitle: String, action: () -> Unit): View {
        val v = infoRow(icon, title, subtitle)
        v.setOnClickListener { action() }
        return v
    }

    private fun profileCard(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)); setBackgroundColor(Color.rgb(236, 247, 238)) }
        box.addView(TextView(this).apply { text = "👨🏻"; textSize = 42f }, LinearLayout.LayoutParams(dp(65), dp(70)))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(label("Arpit Nayak", dark, true), lp())
        col.addView(label("Hey there! I am using India Talk.", Color.DKGRAY, false), lp())
        box.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        return box
    }

    private fun centerAvatar(avatar: String, title: String): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(12), dp(20), dp(12), dp(20)) }
        box.addView(TextView(this).apply { text = avatar; textSize = 58f; gravity = Gravity.CENTER }, lp())
        box.addView(label(title, dark, true), lp())
        return box
    }

    private fun addBubble(parent: LinearLayout, sender: String, text: String, outgoing: Boolean) {
        val bubble = TextView(this).apply {
            this.text = "$sender\n$text\n9:32 AM"
            textSize = 13f; setTextColor(dark); setPadding(dp(14), dp(9), dp(14), dp(9));
            setBackgroundColor(if (outgoing) Color.rgb(220, 247, 206) else Color.WHITE)
        }
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = if (outgoing) Gravity.RIGHT else Gravity.LEFT; setPadding(dp(4), dp(5), dp(4), dp(5)) }
        wrap.addView(bubble, LinearLayout.LayoutParams(dp(260), -2))
        parent.addView(wrap, lp())
    }

    private fun appBar(title: String, icon: String): View {
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(10)); setBackgroundColor(Color.WHITE) }
        bar.addView(TextView(this).apply { text = icon; textSize = 25f }, LinearLayout.LayoutParams(dp(45), dp(52)))
        bar.addView(label(title, dark, true), LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(TextView(this).apply { text = "🔍  ⋮"; textSize = 18f }, LinearLayout.LayoutParams(dp(80), dp(52)))
        return bar
    }

    private fun chatBar(title: String, subtitle: String): View {
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8)); setBackgroundColor(Color.WHITE) }
        val back = Button(this).apply { text = "‹"; isAllCaps = false; setOnClickListener { showHome() } }
        bar.addView(back, LinearLayout.LayoutParams(dp(48), dp(58)))
        bar.addView(TextView(this).apply { text = "👤"; textSize = 28f }, LinearLayout.LayoutParams(dp(45), dp(58)))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(label(title, dark, true), lp())
        col.addView(label(subtitle, green, false), lp())
        bar.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(TextView(this).apply { text = "📞  🎥  ⋮"; textSize = 17f }, LinearLayout.LayoutParams(dp(120), dp(58)))
        return bar
    }

    private fun bottomNav(selected: Int): View {
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(Color.WHITE); setPadding(4, 4, 4, 4) }
        val labels = listOf("💬\nChats", "◉\nStatus", "☎\nCalls", "•••\nMore")
        labels.forEachIndexed { i, text ->
            val b = Button(this).apply { this.text = text; isAllCaps = false; textSize = 11f; setTextColor(if (i == selected) orange else dark) }
            b.setOnClickListener { when (i) { 0 -> showHome(); 1 -> showStatus(); 2 -> showCalls(); else -> showMore() } }
            nav.addView(b, LinearLayout.LayoutParams(0, dp(64), 1f))
        }
        return nav
    }

    private fun label(text: String, color: Int, bold: Boolean): TextView = TextView(this).apply { this.text = text; textSize = if (bold) 15f else 12f; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD; setPadding(2, 2, 2, 2) }

    private fun badge(text: String): TextView = TextView(this).apply { this.text = text; textSize = 10f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setBackgroundColor(green); setPadding(dp(7), dp(3), dp(7), dp(3)) }

    private fun baseRoot(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(light) }
    private fun lp() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun aboutDialog() {
        AlertDialog.Builder(this).setTitle("India Talk").setMessage("Connect. Share. Stay Together.\n\nFounder: Arpit Nayak\n\nThis build is a local UI prototype. Firebase, authentication, messaging, calls and server APIs must be connected before public production launch.").setPositiveButton("OK", null).show()
    }

    data class Chat(val name: String, val message: String, val time: String, val badge: String)
}
