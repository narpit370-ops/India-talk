package com.indiatalk.app

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class IndiaTalkFirebaseMessagingService : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        // TODO: POST this token to /devices/register after the user is authenticated.
        // Never log push tokens in production.
    }

    override fun onMessageReceived(message: RemoteMessage) {
        // TODO: route data payload to the notification/chat layer.
        // Avoid putting sensitive message text in notification payloads.
    }
}
