require("dotenv").config();
const express = require("express");
const http = require("http");
const helmet = require("helmet");
const cors = require("cors");
const rateLimit = require("express-rate-limit");
const jwt = require("jsonwebtoken");
const { Server } = require("socket.io");
const { z } = require("zod");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: process.env.CORS_ORIGIN || "*" } });

app.use(helmet());
app.use(cors({ origin: process.env.CORS_ORIGIN || "*" }));
app.use(express.json({ limit: "1mb" }));
app.use(rateLimit({ windowMs: 60_000, limit: 120 }));

const secret = process.env.JWT_SECRET;
if (!secret && process.env.NODE_ENV === "production") throw new Error("JWT_SECRET is required");

app.get("/health", (_,res)=>res.json({
  ok:true, service:"India Talk API", version:"1.0.0", founder:"Arpit Nayak"
}));

function auth(req,res,next){
  try {
    const raw=(req.headers.authorization||"").replace(/^Bearer\s+/i,"");
    req.user=jwt.verify(raw, secret || "development-only");
    next();
  } catch { res.status(401).json({error:"Unauthorized"}); }
}

/* Provider adapters are deliberately explicit.
   Connect real OTP, Firebase Admin, S3, Prisma and TURN credentials before launch. */
app.post("/auth/request-otp",(req,res)=>{
  const p=z.object({phone:z.string().min(8).max(20)}).safeParse(req.body);
  if(!p.success) return res.status(400).json({error:"Invalid phone"});
  res.status(501).json({error:"Connect approved SMS/OTP provider before production"});
});

app.post("/auth/verify-otp",(req,res)=>{
  const p=z.object({phone:z.string(),otp:z.string().length(6)}).safeParse(req.body);
  if(!p.success) return res.status(400).json({error:"Invalid OTP"});
  res.status(501).json({error:"Connect OTP verification adapter before production"});
});

app.get("/users/me",auth,(req,res)=>res.json({id:req.user.sub,name:req.user.name,phone:req.user.phone}));
app.post("/devices/register",auth,(req,res)=>res.status(501).json({error:"Persist FCM token with Prisma"}));
app.post("/media/presign",auth,(req,res)=>res.status(501).json({error:"Connect S3-compatible storage"}));
app.post("/calls",auth,(req,res)=>res.status(501).json({error:"Connect WebRTC signaling + TURN"}));
app.post("/reports",auth,(req,res)=>res.json({ok:true}));

io.use((socket,next)=>{
  try { socket.user=jwt.verify(socket.handshake.auth?.token||"",secret||"development-only"); next(); }
  catch { next(new Error("Unauthorized")); }
});
io.on("connection",socket=>{
  socket.join("user:"+socket.user.sub);
  socket.on("conversation:join", id=>socket.join("conversation:"+id));
  socket.on("message:send", payload=>{
    if(!payload?.conversationId) return;
    io.to("conversation:"+payload.conversationId).emit("message:new",{
      ...payload,senderId:socket.user.sub
    });
  });
  socket.on("call:offer",p=>io.to("user:"+p.calleeId).emit("call:offer",{...p,callerId:socket.user.sub}));
  socket.on("call:answer",p=>io.to("user:"+p.callerId).emit("call:answer",{...p,calleeId:socket.user.sub}));
  socket.on("call:ice",p=>io.to("user:"+p.peerId).emit("call:ice",{...p,peerId:socket.user.sub}));
});

server.listen(process.env.PORT||3000,()=>console.log("India Talk API listening"));
