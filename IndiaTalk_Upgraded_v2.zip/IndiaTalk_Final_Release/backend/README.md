# India Talk production backend

Stack:
- Node.js + Express
- PostgreSQL + Prisma
- Socket.IO
- Firebase Admin/FCM integration point
- OTP provider integration point
- S3-compatible media integration point
- WebRTC/TURN signaling integration point

## Deploy
1. Create PostgreSQL.
2. Set `.env` from `.env.example`.
3. `npm install`
4. `npx prisma generate`
5. `npx prisma migrate deploy`
6. `npm start`

Do not deploy until real provider adapters are connected and tested.
